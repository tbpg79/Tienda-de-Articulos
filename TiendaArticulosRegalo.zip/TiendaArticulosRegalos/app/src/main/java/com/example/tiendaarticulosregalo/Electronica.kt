package com.example.tiendaarticulosregalo

import androidx.compose.runtime.Composable

@Composable
fun Electronica(){

}