package com.example.tiendaarticulosregalo

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import java.security.Principal

@Composable
fun Principal(){
    LazyColumn() {
        item {
            Text(text = "Principal", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        }
    }
}